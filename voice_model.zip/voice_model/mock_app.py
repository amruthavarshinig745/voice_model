import os
import sys
import time
# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'backend', 'src'))

from audio_monitor import MoroVoiceAssistant

def simulate_system():
    # Initialize assistant with paths relative to this mock app
    assistant = MoroVoiceAssistant(
        assets_dir="backend/audio_assets", 
        config_file="backend/voice_config.json"
    )
    
    print("\n--- Moro-AI Simulation Started ---")
    print("Initializing active modules...")
    time.sleep(1)
    
    # 1. Simulate Model 1 (Security) - Unknown Person
    print("\n[EVENT] Model 1: Security Camera detects unknown person...")
    assistant.speak("MODEL_1", "UNKNOWN_PERSON")
    time.sleep(3)
    
    # 2. Simulate Model 2 (Threat) - Tiger Detected
    print("\n[EVENT] Model 2: Threat Detector identifies a wild animal (Snake)...")
    assistant.speak("MODEL_2", "SNAKE_DETECTED")
    time.sleep(3)
    
    # 3. Simulate Model 3 (Dashcam) - SOS Trigger
    print("\n[EVENT] Model 3: Dashcam user triggers SOS button...")
    assistant.speak("MODEL_3", "SOS_TRIGGERED")
    time.sleep(3)
    
    # 4. Simulate Model 4 (Analytics) - Staff Attendance
    print("\n[EVENT] Model 4: Human Analytics logs staff entry...")
    assistant.speak("MODEL_4", "STAFF_ENTRY")

if __name__ == "__main__":
    # Check if config exists, if not, create some defaults for demo
    config_path = "backend/voice_config.json"
    if not os.path.exists(config_path):
        print("Note: No phrases configured yet. Please run voice_manager_cli.py first.")
        print("Creating some sample phrases for demonstration...")
        
        # Ensure directory exists for assistant init
        os.makedirs("backend/audio_assets", exist_ok=True)
        
        assistant = MoroVoiceAssistant(
            assets_dir="backend/audio_assets", 
            config_file=config_path
        )
        
        # Adding sample phrases
        assistant.add_and_store("MODEL_1", "UNKNOWN_PERSON", "Warning! Unknown person detected at the entrance.", "en")
        assistant.add_and_store("MODEL_2", "SNAKE_DETECTED", "Warning! A snake is detected outside. Please stay inside.", "en")
        assistant.add_and_store("MODEL_3", "SOS_TRIGGERED", "SOS triggered. Your location has been sent. Stay calm, help is on the way.", "en")
        assistant.add_and_store("MODEL_4", "STAFF_ENTRY", "Welcome. Your attendance has been marked.", "en")
        
    simulate_system()
