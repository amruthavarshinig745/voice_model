import os
import sys
# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from audio_monitor import MoroVoiceAssistant

def main():
    assistant = MoroVoiceAssistant(
        assets_dir="audio_assets", 
        config_file="voice_config.json"
    )
    
    print("\n" + "="*40)
    print("      MORO-AI VOICE MANAGER CLI")
    print("="*40)
    
    while True:
        print("\nMain Menu:")
        print("1. Add/Record New Phrase")
        print("2. Test/Speak Existing Phrase")
        print("3. Exit")
        
        choice = input("\nSelect an option (1-3): ")
        
        if choice == '1':
            print("\n--- Register New Phrase ---")
            print("Select Model Module:")
            print("1. MODEL_1 - Security")
            print("2. MODEL_2 - Threat & Safety")
            print("3. MODEL_3 - Dashcam")
            print("4. MODEL_4 - Analytics")
            
            m_choice = input("Select Model (1-4): ")
            model_id = f"MODEL_{m_choice}"
            
            event_type = input("Enter Event Type (e.g., TIGER_DETECTED, ALERT, SOS): ").upper()
            text = input("Enter the text to speak (Any Language): ")
            
            print("\nGenerating preview...")
            filepath, lang = assistant.generate_audio(model_id, event_type, text)
            print(f"Detected Language: {lang}")
            
            while True:
                assistant.preview_audio(filepath)
                confirm = input("\nDo you agree with this audio? (y/n/r for replay): ").lower()
                if confirm == 'y':
                    assistant.add_and_store(model_id, event_type, text, lang)
                    print(f"Phrase stored successfully for {model_id} - {event_type}!")
                    break
                elif confirm == 'n':
                    print("Action cancelled.")
                    # Clean up temp file if not stored
                    if os.path.exists(filepath):
                        os.remove(filepath)
                    break
                elif confirm == 'r':
                    continue
                    
        elif choice == '2':
            print("\n--- Test Voice Alert ---")
            m_choice = input("Select Model (1-4): ")
            model_id = f"MODEL_{m_choice}"
            event_type = input("Enter Event Type: ").upper()
            assistant.speak(model_id, event_type)
            
        elif choice == '3':
            print("Exiting Voice Manager. Goodbye!")
            break
        else:
            print("Invalid choice, try again.")

if __name__ == "__main__":
    main()
